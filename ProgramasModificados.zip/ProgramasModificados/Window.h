#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	GLfloat getmuevex() { return muevex; }
	GLfloat getmuevexAv1() { return muevexAv1; }
	GLfloat getmuevexAv2() { return muevexAv2; }
	GLfloat getmuevexNav1() { return muevexNav1; }
	GLfloat getmuevexNav2() { return muevexNav2; }

	// Tecla para prender y apagar la luz del holocron
	bool getTeclaHoloPresionada() { return teclaHoloPresionada; }
	void resetTeclaHoloPresionada() { teclaHoloPresionada = false; }

	// Tecla para prender y apagar la luz del rover
	bool getTeclaRoverPresionada() { return teclaRoverPresionada; }
	void resetTeclaRoverPresionada() { teclaRoverPresionada = false; }

	// Para cambiar de color la luz del faro del avioncito
	bool getCiclarColor() { return ciclarColor; }

	// Para prender y apagar las luces de la nave
	bool getTeclaNavePresionada() { return teclaNavePresionada; }

	// Para prender y apagar la luz del motor 1 de la nave
	bool getTeclaMotor1() { return teclaMotor1; }
	void resetTeclaMotor1() { teclaMotor1 = false; }

	// Para prender y apagar la luz del motor 2 de la nave
	bool getTeclaMotor2() { return teclaMotor2; }
	void resetTeclaMotor2() { teclaMotor2 = false; }

	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	
	~Window();
private: 
	GLFWwindow *mainWindow;
	GLint width, height;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	GLfloat muevex;
	GLfloat muevexAv1;
	GLfloat muevexAv2;
	GLfloat muevexNav1;
	GLfloat muevexNav2;
	GLboolean teclaNavePresionada;
	GLboolean teclaMotor1;
	GLboolean teclaMotor2;
	GLboolean teclaHoloPresionada;
	GLboolean teclaRoverPresionada;
	GLboolean ciclarColor;
	bool mouseFirstMoved;
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);

};

