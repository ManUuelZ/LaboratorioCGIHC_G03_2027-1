#include "Window.h"

Window::Window()
{
	width = 800;
	height = 600;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;
	muevex = 2.0f;
	muevexAv1= 0.0f;
	muevexAv2 = 0.0f;
	muevexNav1 = 0.0f;
	muevexNav2 = 0.0f;
	teclaNavePresionada = GL_TRUE;
	teclaHoloPresionada = GL_TRUE;
	teclaRoverPresionada = GL_TRUE;
	teclaMotor1 = GL_FALSE;
	teclaMotor2 = GL_FALSE;
	ciclarColor = GL_FALSE; 
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
int Window::Initialise()
{
	//Inicializaci�n de GLFW
	if (!glfwInit())
	{
		printf("Fall� inicializar GLFW");
		glfwTerminate();
		return 1;
	}
	//Asignando variables de GLFW y propiedades de ventana
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//para solo usar el core profile de OpenGL y no tener retrocompatibilidad
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	//CREAR VENTANA
	mainWindow = glfwCreateWindow(width, height, "Practica08: Iluminacion 2", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo en crearse la ventana con GLFW");
		glfwTerminate();
		return 1;
	}
	//Obtener tama�o de Buffer
	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);

	//asignar el contexto
	glfwMakeContextCurrent(mainWindow);

	//MANEJAR TECLADO y MOUSE
	createCallbacks();


	//permitir nuevas extensiones
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("Fall� inicializaci�n de GLEW");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST); //HABILITAR BUFFER DE PROFUNDIDAD
							 // Asignar valores de la ventana y coordenadas
							 
							 //Asignar Viewport
	glViewport(0, 0, bufferWidth, bufferHeight);
	//Callback para detectar que se est� usando la ventana
	glfwSetWindowUserPointer(mainWindow, this);
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}
GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}




void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}
	if (key == GLFW_KEY_Y)
	{
		theWindow-> muevex += 1.0;
	}
	if (key == GLFW_KEY_U)
	{
		theWindow-> muevex -= 1.0;
	}
	if (key == GLFW_KEY_M) 
	{ 
		theWindow->muevexAv1 += 1.0; 
	} 
	if (key == GLFW_KEY_N) 
	{ 
		theWindow->muevexAv1 -= 1.0; 
	}
	if (key == GLFW_KEY_X)
	{
		theWindow->muevexAv2 += 1.0;
	}
	if (key == GLFW_KEY_Z)
	{
		theWindow->muevexAv2 -= 1.0;
	}
	if (key == GLFW_KEY_1 && action == GLFW_PRESS)
	{
		theWindow-> teclaHoloPresionada = !theWindow->teclaHoloPresionada;
	}
	if (key == GLFW_KEY_2 && action == GLFW_PRESS)
	{
		theWindow-> teclaRoverPresionada = !theWindow->teclaRoverPresionada;
	}
	if (key == GLFW_KEY_3 && action == GLFW_PRESS)
	{
		theWindow->ciclarColor = !theWindow->ciclarColor;
	}
	if (key == GLFW_KEY_4 && action == GLFW_PRESS)
	{
		theWindow->teclaNavePresionada = !theWindow->teclaNavePresionada;
	}
	if (key == GLFW_KEY_5 && action == GLFW_PRESS)
	{
		theWindow->teclaMotor1 = !theWindow->teclaMotor1;
	}
	if (key == GLFW_KEY_6 && action == GLFW_PRESS)
	{
		theWindow->teclaMotor2 = !theWindow->teclaMotor2;
	}
	if (key == GLFW_KEY_V)
	{
		theWindow->muevexNav1 += 1.0;
	}
	if (key == GLFW_KEY_C)
	{
		theWindow->muevexNav1 -= 1.0;
	}
	if (key == GLFW_KEY_F)
	{
		theWindow->muevexNav2 += 1.0;
	}
	if (key == GLFW_KEY_G)
	{
		theWindow->muevexNav2 -= 1.0;
	}

	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
			//printf("se presiono la tecla %d'\n", key);
		}
		else if (action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
			//printf("se solto la tecla %d'\n", key);
		}
	}
}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;

	theWindow->lastX = xPos;
	theWindow->lastY = yPos;
}


Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();

}
